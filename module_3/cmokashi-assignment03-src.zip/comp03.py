"""
Class containing code for assignment 3
"""
"""
Author: Chinmay Mokashi
Date: 2022-09-26
Version: 1.0
"""

import matplotlib.pyplot as plt
import numpy as np


class Fourier:
    pass